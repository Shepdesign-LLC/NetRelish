-- MySQL dump 8.0 (sample) — press_tools
-- Generated 2026-09-14 for import testing. Safe to drop.

/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;

CREATE DATABASE IF NOT EXISTS `press_tools` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `press_tools`;

DROP TABLE IF EXISTS `releases`;
DROP TABLE IF EXISTS `tools`;
DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(190) NOT NULL,
  `display_name` varchar(120) NOT NULL,
  `role` enum('owner','editor','viewer') NOT NULL DEFAULT 'viewer',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `tools` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(64) NOT NULL,
  `name` varchar(120) NOT NULL,
  `tagline` varchar(255) DEFAULT NULL,
  `status` enum('idea','building','shipped','archived') NOT NULL DEFAULT 'idea',
  `owner_id` int unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_slug` (`slug`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_tools_owner` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `releases` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `tool_id` int unsigned NOT NULL,
  `version` varchar(20) NOT NULL,
  `notes` text,
  `size_kb` decimal(8,1) DEFAULT NULL,
  `released_at` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tool_version` (`tool_id`,`version`),
  CONSTRAINT `fk_releases_tool` FOREIGN KEY (`tool_id`) REFERENCES `tools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `users` (`id`,`email`,`display_name`,`role`,`created_at`) VALUES
(1,'ryan@shepdesign.com','Ryan','owner','2026-09-01 09:00:00'),
(2,'editor@example.com','Sample Editor','editor','2026-09-05 14:30:00'),
(3,'viewer@example.com','Sample Viewer','viewer','2026-09-10 08:15:00');

INSERT INTO `tools` (`id`,`slug`,`name`,`tagline`,`status`,`owner_id`,`created_at`) VALUES
(1,'md-press','MD Press','Markdown reader and HTML exporter','shipped',1,'2026-09-13 01:00:00'),
(2,'mail-press','Mail Press','HTML email generator that survives Outlook','shipped',1,'2026-09-13 20:00:00'),
(3,'press-kit','PressKit','Shared SwiftUI shell for the macOS collection','idea',1,'2026-09-13 21:00:00');

INSERT INTO `releases` (`tool_id`,`version`,`notes`,`size_kb`,`released_at`) VALUES
(1,'1.0.0','First single-file build',44.0,'2026-09-13'),
(1,'1.1.0','Bundled parser, offline core',353.0,'2026-09-13'),
(1,'1.2.0','Skins, copy buttons, locked tabs, PWA',361.0,'2026-09-13'),
(2,'1.0.0','Inliner, linter, Outlook simulation, text twin',48.0,'2026-09-13'),
(2,'1.1.0','Route selection and server proxy',52.0,'2026-09-13');

/*!40014 SET FOREIGN_KEY_CHECKS=1 */;
-- Dump completed
